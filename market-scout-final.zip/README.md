# 🇹🇷 Market Scout v3 — Gerçek Zamanlı Kurulum

Her sabah **09:00**'da Hacker News + TechCrunch'ı tarar,
Claude ile analiz eder, Telegram'a gönderir ve web sayfasını günceller.

---

## Kurulum Adımları

### 1. NewsAPI Key Al (2 dk — Ücretsiz)
1. [newsapi.org](https://newsapi.org) → **Get API Key**
2. E-posta ile kayıt ol
3. API key'ini kopyala

### 2. Telegram Bot Kur (2 dk)
1. Telegram → **@BotFather** → `/newbot`
2. Token'ı kopyala
3. Bota bir mesaj gönder
4. `https://api.telegram.org/bot<TOKEN>/getUpdates` → Chat ID'yi al

### 3. Anthropic API Key Al (3 dk)
1. [console.anthropic.com](https://console.anthropic.com) → Sign up
2. **API Keys** → **Create Key**
3. `sk-ant-...` ile başlayan key'i kopyala

### 4. GitHub Repo Aç
1. [github.com/new](https://github.com/new) → yeni repo (public olmalı — Pages için)
2. Bu 2 dosyayı yükle:
   - `scout.py`
   - `.github/workflows/daily-scout.yml`

### 5. GitHub Pages Aktif Et
Repo → **Settings** → **Pages** → Source: **gh-pages branch**

### 6. 4 Secret Ekle
Repo → **Settings** → **Secrets and variables** → **Actions**

| Secret | Değer |
|--------|-------|
| `ANTHROPIC_API_KEY` | Anthropic'ten aldığın key |
| `NEWS_API_KEY` | NewsAPI'den aldığın key |
| `TELEGRAM_TOKEN` | BotFather'dan aldığın token |
| `TELEGRAM_CHAT_ID` | getUpdates'ten aldığın sayı |

### 7. Test Et
**Actions** → **Market Scout v3** → **Run workflow**

✅ 1-2 dakika içinde:
- Telegram'a mesaj gelir
- `https://KULLANICIADIN.github.io/REPOADI` sayfası güncellenir

---

## Maliyet
| Servis | Maliyet |
|--------|---------|
| GitHub Actions | Ücretsiz |
| GitHub Pages | Ücretsiz |
| NewsAPI | Ücretsiz (100 istek/gün) |
| Hacker News API | Tamamen ücretsiz |
| Anthropic API | ~$0.01-0.03 / gün |
| Telegram | Ücretsiz |

**Toplam: ~$0.30-0.90 / ay**
